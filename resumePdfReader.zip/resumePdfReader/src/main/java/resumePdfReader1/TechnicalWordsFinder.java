package resumePdfReader1;

import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;



public class TechnicalWordsFinder {
	 public static void main(String[] args) {
	        String directoryPath = "C:\\Users\\HP\\Desktop"; 

	        File directory = new File(directoryPath);
	        if (directory.exists() && directory.isDirectory()) {
	            File[] files = directory.listFiles();

	            if (files != null) {
	                String[] technicalWords = {"J2EE","Frameworks","Manual Testing","JAVA","JavaScript","SQL","HTML","CSS"};

	                for (File file : files) {
	                    if (file.isFile() && file.getName().toLowerCase().endsWith(".pdf")) {
	                        try {
	                            String resumeText = readPdfFile(file);
	                            checkTechnicalWords(file, resumeText, technicalWords);
	                        } catch (IOException e) {
	                            e.printStackTrace();
	                        }
	                    }
	                }
	            } else {
	                System.out.println("No files found in the specified directory.");
	            }
	        } else {
	            System.out.println("Invalid directory path.");
	        }
	    }

	    private static String readPdfFile(File file) throws IOException {
	        PDDocument document = PDDocument.load(file);
	        PDFTextStripper pdfStripper = new PDFTextStripper();
	        String content = pdfStripper.getText(document);
	        document.close();
	        return content;
	    }

	    private static void checkTechnicalWords(File file, String resumeText, String[] technicalWords) {
	        for (String techWord : technicalWords) {
	            Pattern pattern = Pattern.compile("\\b" + techWord + "\\b", Pattern.CASE_INSENSITIVE);
	            Matcher matcher = pattern.matcher(resumeText);

	            while (matcher.find()) {
	                System.out.println("Technical keyword '" + matcher.group() + "' in file: " + file.getName());
	            }
	        }
	    }

}
